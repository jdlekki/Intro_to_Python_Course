def myfunc():
    return 1

def print_name(name):
    """Returns a name with apple at the end"""
    
    
    return name + "-apple"
