from myrepolib import repomod


def test_func():
    result = repomod.myfunc()
    assert result == 1
